const mongoose = require('mongoose');

// Define o esquema de comentários guardados no banco de dados NoSQL
const ComentarioSchema = new mongoose.Schema({
    receitaId: { 
        type: Number, 
        required: true 
    },
    autor: { 
        type: String, 
        required: true 
    },
    texto: { 
        type: String, 
        required: true 
    },
    data: { 
        type: Date, 
        default: Date.now 
    }
});

module.exports = mongoose.model('Comentario', ComentarioSchema);