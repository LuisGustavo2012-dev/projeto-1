const sequelize = require('../config/db');
const Sequelize = require('sequelize');

// Importação de todos os modelos definidos
const Aluno = require('./aluno')(sequelize, Sequelize);
const Receita = require('./receita')(sequelize, Sequelize);
const Categoria = require('./categoria')(sequelize, Sequelize);
const Habilidade = require('./habilidade')(sequelize, Sequelize);
const AlunoHabilidade = require('./alunohabilidade')(sequelize, Sequelize);

// Associa Receitas a Categorias (Muitos-para-Muitos)
Receita.belongsToMany(Categoria, {
    through: 'receita_categoria',
    as: 'categorias'
});
Categoria.belongsToMany(Receita, {
    through: 'receita_categoria',
    as: 'receitas'
});

// Associa Alunos às suas Receitas (Um Aluno tem muitas Receitas)
Aluno.hasMany(Receita, { foreignKey: 'alunoId', as: 'minhasReceitas', onDelete: 'CASCADE' });
Receita.belongsTo(Aluno, { foreignKey: 'alunoId', as: 'autor' });

// Associa Alunos a Habilidades através da tabela de nível (Muitos-para-Muitos)
Aluno.belongsToMany(Habilidade, {
    through: AlunoHabilidade,
    as: 'habilidades'
});
Habilidade.belongsToMany(Aluno, {
    through: AlunoHabilidade,
    as: 'alunosHabilidade'
});

module.exports = {
    db: sequelize,
    Sequelize,
    Aluno,
    Receita,
    Categoria,
    Habilidade,
    AlunoHabilidade
};