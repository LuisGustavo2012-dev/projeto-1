const { Aluno } = require('./models');

async function criarAdmin() {
    try {
        // O upsert tenta atualizar; se não achar o e-mail, ele cria um novo.
        await Aluno.upsert({
            nome: 'Administrador',
            email: 'jgroquedesiderio@gmail.com',
            senha: '1234',
            tipo: 'admin'
        });
        
        console.log('✅ Admin configurado (criado ou atualizado)!');
        process.exit(); // Fecha o script sozinho após terminar
    } catch (e) {
        console.error('❌ Erro:', e.message);
        process.exit(1);
    }
}

criarAdmin();