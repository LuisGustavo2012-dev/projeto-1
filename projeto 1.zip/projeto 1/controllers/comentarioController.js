const Comentario = require('../models/comentario');

const comentarioCtrl = {
    // Salva um comentário associado a uma receita
    async criar(req, res) {
        try {
            const { receitaId, texto } = req.body;
            const autor = req.session.usuario ? req.session.usuario.nome : 'Anônimo';

            const novoComentario = await Comentario.create({
                receitaId: Number(receitaId),
                autor,
                texto
            });
            res.status(201).json(novoComentario);
        } catch (erro) {
            res.status(500).json({ erro: 'Erro ao salvar' });
        }
    },

    // Busca comentários de uma receita específica no MongoDB
    async listarPorReceita(req, res) {
        try {
            const { receitaId } = req.params;
            const comentarios = await Comentario.find({ receitaId: Number(receitaId) }).sort({ data: -1 });
            res.json(comentarios);
        } catch (erro) {
            res.status(500).json({ erro: 'Erro ao buscar' });
        }
    }
};

module.exports = comentarioCtrl;