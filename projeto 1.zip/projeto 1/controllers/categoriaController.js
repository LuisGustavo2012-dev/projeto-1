/**
 * Controller: CategoriaController
 * Responsável por gerenciar as categorias das receitas (ex: Sobremesas, Salgados, Vegana).
 */
const { Categoria } = require('../models');

module.exports = {
    
    // LISTAR: Retorna todas as categorias cadastradas
    async listar(req, res) {
        try {
            // Busca todos os registros na tabela 'categorias'
            const categorias = await Categoria.findAll();
            
            res.json(categorias); 
        } catch (e) {
            console.error("Erro ao listar categorias:", e);

            res.status(500).json([]); 
        }
    },

    // CADASTRAR: Cria uma nova categoria no sistema
    async cadastrar(req, res) {
        try {
            const { nome } = req.body;

            // Validação simples: impede a criação de categorias sem nome
            if (!nome) {
                return res.status(400).json({ sucesso: false, mensagem: "O nome é obrigatório" });
            }
            
            // Cria o registro no banco de dados
            const novaCategoria = await Categoria.create({ nome });
            
            // Retorna o objeto criado com status 201 (Created)
            res.status(201).json(novaCategoria);
        } catch (e) {
     
            if (e.name === 'SequelizeUniqueConstraintError') {
                return res.status(400).json({ sucesso: false, mensagem: "Esta categoria já existe." });
            }
            res.status(500).json({ sucesso: false, mensagem: e.message });
        }
    },

    // EXCLUIR: Remove uma categoria pelo seu ID
    async excluir(req, res) {
        try {
            const { id } = req.params;

            // destroy() retorna a quantidade de linhas deletadas
            const deletado = await Categoria.destroy({ where: { id } });

            if (deletado) {
           
                res.json({ sucesso: true, mensagem: "Categoria removida com sucesso!" });
            } else {
                res.status(404).json({ sucesso: false, mensagem: "Categoria não encontrada." });
            }
        } catch (e) {
      
            res.status(500).json({ 
                sucesso: false, 
                mensagem: "Não é possível excluir: existem receitas usando esta categoria." 
            });
        }
    }
};