const { Habilidade, Aluno, AlunoHabilidade } = require('../models');

module.exports = {
   // Lista todas as habilidades globais cadastradas
    async listar(req, res) {
        try {
            const habilidades = await Habilidade.findAll();
            res.json(habilidades); 
        } catch (e) {
            res.status(500).json([]);
        }
    },

    // Adiciona uma nova habilidade à lista global (Admin)
    async cadastrar(req, res) {
        try {
            const { nome } = req.body;
            const novaHabilidade = await Habilidade.create({ nome });
            res.status(201).json(novaHabilidade);
        } catch (e) {
            res.status(500).json({ erro: e.message });
        }
    },



    /// Vincula uma habilidade ao perfil do aluno logado com um nível
    async salvarNivel(req, res) {
    try {
        const { habilidadeId, nivel } = req.body;
        const alunoId = req.session.usuario.id;

        const { Aluno } = require('../models');
        const aluno = await Aluno.findByPk(alunoId);

        // O segredo está aqui: o Sequelize atualiza o 'nivel' na tabela pivô
        await aluno.addHabilidade(habilidadeId, { 
            through: { nivel: nivel } 
        });

        res.json({ sucesso: true, mensagem: "Nível atualizado!" });
    } catch (e) {
        res.status(500).json({ erro: e.message });
    }
}

    
};